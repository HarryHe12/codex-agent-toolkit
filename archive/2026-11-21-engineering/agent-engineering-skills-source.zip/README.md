# Agent engineering skills

三个按需使用的工程 skill，参考 Lauren Tan 的 pstack，并依据隔离任务的实际结果做了适配。不会替换项目已有的测试、部署授权或质量门禁。

| Skill | 使用场景 |
| --- | --- |
| `project-verification` | 缺少可靠的产品验证指南，或已有指南随产品变化而失效 |
| `prevent-repeat-errors` | 有证据表明同类错误反复出现，需要结构或可执行检查阻止重犯 |
| `evaluate-agent-skills` | 要判断 skill／提示改动是否真正改善结果，而不只是增加步骤 |

## 使用与打包

`skill-sources/*.stage` 是经过审阅的分发源文件。打包后得到标准 `skills/<name>/SKILL.md` 结构，不依赖作者机器上的目录或额外治理 skills。

```sh
python3 -m unittest discover -s tests -v
python3 tools/build_package.py --output work/agent-skills.zip
```

在临时目录解压，运行 `python3 tools/check_package.py <解压目录>` 检查本地依赖。安装时先核对目标环境已有同名 skill，使用该环境的指令审阅和安装流程，保留原版本；不要盲目覆盖已有定制。

在当前 Codex 环境中，三个 skill 已安装到用户级目录。可以显式使用 `$project-verification`、`$prevent-repeat-errors`、`$evaluate-agent-skills`，也可由任务匹配加载。

## 实际测试与限制

2026-11-21 进行了四组独立会话的成对任务，共 8 次初始执行；根据问题优化后又执行了 3 次。另有一轮匿名产物审查，以及独立脚本复验。

| 检查 | 未加入 skill | 第一版 | 优化版 |
| --- | --- | --- | --- |
| 边界检查：原先的 7 个导入案例 | 7/7 | 7/7 | 7/7 |
| 后续发现的空扫描误报案例 | 失败 | 失败 | 通过 |
| 指南：正常产品通过、去掉 trim 后失败并保留证据 | 2/2 | 2/2 | 2/2 |
| 普通错字修改仅改变目标文字 | 通过 | 通过 | 未重复；触发描述未变 |

优化版验证指南不再为单入口 CLI 强制生成路由 skill 和独立功能地图。该次产物由第一版的 16 个文件降为 9 个；其中包含治理审阅和证据文件，不能把文件数或行数直接当作效率指标。优化版评估计划也不再无依据地要求 36／160 次起步运行或固定提速百分比。

这是诊断性小样本，不证明普遍提速或总体成功率提升。全局 hook 在并行执行时互相阻塞；未取得完整 token／费用数据，不能比较端到端耗时。优化版还使用了已见过的任务，不能当作独立留出集的泛化结果。公开产物不包含浏览器会话、凭据、业务仓库或作者的全局私有规则。

细节见 [结果](evaluations/check-results.json)、[变更规模](evaluations/change-sizes.json) 和 [测试说明](evaluations/report.txt)。

## 复验保存的产物

```sh
python3 tools/check_boundary_submission.py evaluations/submissions/revised/panel
python3 tools/check_guide_submission.py evaluations/submissions/revised/ledger
```

`without-skill` 和 `first-version` 的边界产物会因后来加入的空扫描案例返回非零；这是保留的真实失败，不应通过放宽断言消除。指南复验器针对本仓库的 Ledger 夹具，使用隔离目录及合成 Git 提交；它不是任意应用的通用驱动器。

## 方法来源

- [pstack verification](https://github.com/cursor/plugins/blob/main/pstack/skills/create-verification-skill/SKILL.md)
- [pstack correct](https://github.com/cursor/plugins/blob/main/pstack/skills/correct/SKILL.md)
- [pstack eval](https://github.com/cursor/plugins/blob/main/pstack/skills/poteto-mode/playbooks/eval.md)
- [OpenAI：Testing Agent Skills Systematically with Evals](https://developers.openai.com/blog/eval-skills)

Skill 正文为独立编写的精简适配，未复制上游实现。
