---
name: instruction-maintenance
description: Create or update active AGENTS.md, SKILL.md, business specs and their governing references with canonical ownership, semantic review and local preflight. Use for persistent agent instructions, not ordinary prose or historical logs.
---

# 维护长期指令

## 内容归属

- 全局 AGENTS 只放跨项目偏好与授权边界；项目 AGENTS 只放项目差异、入口和操作边界；业务 Spec 定义行为与独立例子；Skill 保存复用方法。每项规则指定唯一权威位置，其他位置按需引用。
- 仅将影响后续决策的稳定要求加入常驻入口。任务进展、旧工作区、提交编号和验收数字留在历史记录；不要把一次失败推广为永久禁令，不追加“本节覆盖上文”来积累版本。
- 先查现有所有者及相关调用文档，优先更新、合并、替换已有条目。无法自动执行且确需判断的要求才保留为文字；可执行规则以检查器或契约为权威，入口只保留调用位置。
- 入口保持短小，细节按任务条件加载。拆文件必须对应明确作用域，不通过无条件读取多份文档转移体积；体积预算由 `md_rules.py` 统一维护，不把数字再抄到其他文件。

## 写入流程

- 在正式文件之外准备 `.stage` 草稿，用 `/usr/bin/python3 $CODEX_HOME/md-governance/md_write.py analyze --target <正式路径> --draft <草稿路径>` 查看预算、重复、坏链接、相似条目和新增条目 ID。结构问题先修复，不能提高上限或关闭检查。
- 逐条审阅新增及重写条目：明确要求来源、适用条件、唯一所有者、与旧规则的重叠或冲突，以及保留的授权和例外。根据真实对照为各条写理由，不用脚本填充统一的“已检查”结论；相似度提示不能代替语义判断。
- 审阅 JSON 绑定 `target`、`base_sha256`、`candidate_sha256`，填写具体的 `basis`、`ownership`、`overlap`、`conflicts`、`preservation`，并为每个新增条目提供 `id`、`source`、`reason`。文件版本变化后重新审阅；收据只证明完成记录，不证明语义天然正确或获得独立人工批准。
- 使用同一命令的 `apply` 动作，加 `--review <审阅JSON>`。检查及审阅有效后才原子替换正式文件，收据保存在本地状态目录，不注入日常上下文。直接改正式指令而缺收据，会被编辑后及结束前的 Hook 拦截，须修复，不能报告完成。
- 清理时保留有依据的权限、业务含义和例外；历史全文归档并记录去向，不用删字改变授权。有歧义且影响行为的冲突查最新用户决定，无法确定才询问。归档属于证据，不作为现行入口默认读取。

## 验证边界

- 自动检查覆盖字符预算、过长条目、同节重名、规范化重复、跨文件精确重复、本地文件链接、冲突标记、逐条审阅完整性和版本失效；近似改写给出审阅候选。字符预算不是精确 token 数，程序不能保证识别所有语义重复与冲突。
- 文件删除或迁移前检查引用并保全历史；已登记权威文件的删除需要明确的退役维护，不能删文件或本地收据逃过检查。更新治理程序属于显式维护，保留原检查强度、恢复点和回归验证。

Resolve CODEX_HOME to the current user installation directory; if unset, use ~/.codex. Do not copy another user's permissions or project preferences.
