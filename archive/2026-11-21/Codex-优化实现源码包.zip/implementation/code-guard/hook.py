#!/usr/bin/python3
"""Local synchronous Codex gates. Store hashes/diagnostics, never source contents."""
import fcntl,hashlib,json,os,pathlib,shutil,subprocess,sys
BASE=pathlib.Path(__file__).resolve().parent
NODE=os.environ.get('CODEX_GUARD_NODE') or shutil.which('node')
STATE=BASE/'state'
def verify_integrity():
    manifest=BASE/'integrity.json'
    if not manifest.exists(): return
    for name,expected in json.loads(manifest.read_text()).items():
        target=pathlib.Path(name)
        if not target.exists() or hashlib.sha256(target.read_bytes()).hexdigest()!=expected:
            raise RuntimeError('Guard installation changed: '+name+'. Restore the verified version or perform explicitly authorized guard maintenance.')
def run_scan(root,previous,delegated_roots=()):
    if not NODE: raise RuntimeError('Node executable missing; configure CODEX_GUARD_NODE.')
    env=dict(os.environ)
    env.setdefault('CODEX_HOME',str(BASE.parent))
    env.setdefault('CODEX_GUARD_PYTHON',sys.executable)
    env.setdefault('CODEX_GUARD_MD_HOME',str(BASE.parent/'md-governance'))
    p=subprocess.run([NODE,str(BASE/'scan.mjs')],input=json.dumps({'root':str(root),'previous':previous,'delegatedRoots':list(delegated_roots)}),text=True,capture_output=True,timeout=90,env=env)
    if p.returncode: raise RuntimeError(p.stderr[-3000:])
    return json.loads(p.stdout)
def registered_roots(prefix):
    return [json.loads(p.read_text())['root'] for p in STATE.glob(prefix+'-*.json')]
def root_for(event):
    cwd=pathlib.Path(event.get('cwd') or os.getcwd()).resolve()
    tool=event.get('tool_input') or {}
    if isinstance(tool,dict) and tool.get('workdir'): cwd=pathlib.Path(tool['workdir']).resolve()
    p=subprocess.run(['git','-C',str(cwd),'rev-parse','--show-toplevel'],text=True,capture_output=True)
    return pathlib.Path(p.stdout.strip()).resolve() if p.returncode==0 else cwd

def failures(current,baseline):
    errors=[]
    for file,row in current.items():
        old=baseline.get(file,{})
        forced=[m for k,m in row['metrics'].items() if k.startswith('md:managed-')]
        if forced:
            errors.extend('%s:%s %s'%(file,m['line'],m['message']) for m in forced)
            continue
        if row['hash']==old.get('hash') and row['metrics']==old.get('metrics'): continue
        for key,m in row['metrics'].items():
            before=old.get('metrics',{}).get(key,{})
            hard=key.startswith(('parse:','guard:unsupported','guard:symlink')) or key=='parse' or key=='md:review-required'
            if hard or m['value']>before.get('value',0) or m['count']>before.get('count',0):
                errors.append('%s:%s %s'%(file,m['line'],m['message']))
    return errors

def main(event):
    kind=event.get('hook_event_name','Stop')
    sid=str(event.get('session_id','manual'))
    prefix=hashlib.sha256(sid.encode()).hexdigest()[:20]
    if kind in ('Stop','SubagentStop') and not event.get('_single_root'):
        for saved in STATE.glob(prefix+'-*.json'):
            data=json.loads(saved.read_text())
            outcome=main(dict(event,cwd=data['root'],tool_input={},_single_root=True))
            if outcome.get('decision')=='block': return outcome
        return {}
    root=root_for(event)
    STATE.mkdir(mode=0o700,exist_ok=True)
    os.chmod(STATE,0o700)
    sid=str(event.get('session_id','manual'))
    key=prefix+'-'+hashlib.sha256(str(root).encode()).hexdigest()
    statefile=STATE/(key+'.json')
    rootkey=hashlib.sha256(str(root).encode()).hexdigest()
    baselinefile=STATE/('baseline-'+rootkey+'.json')
    with (STATE/('root-'+rootkey+'.lock')).open('a') as lock:
        fcntl.flock(lock,fcntl.LOCK_EX)
        if statefile.exists(): data=json.loads(statefile.read_text())
        else:
            if kind not in ('SessionStart','PreToolUse'):
                raise RuntimeError('Missing pre-edit baseline. Cannot certify this turn; initialize before the next edit, preserving current changes for review.')
            snapshot=run_scan(root,{},registered_roots(prefix))
            baseline=json.loads(baselinefile.read_text()) if baselinefile.exists() else snapshot
            if not baselinefile.exists():
                baselinefile.write_text(json.dumps(baseline)); os.chmod(baselinefile,0o600)
            data={'root':str(root),'baseline':baseline,'latest':snapshot}
            statefile.write_text(json.dumps(data)); os.chmod(statefile,0o600)
        if kind in ('SessionStart','PreToolUse'):
            if kind=='SessionStart':
                return {'hookSpecificOutput':{'hookEventName':kind,'additionalContext':'Global local-code-guard active: read the installed local-code-guard Skill before coding. Code and persistent instruction edits are scanned synchronously and finalization is gated; read the installed instruction-maintenance Skill before changing instruction documents. Unsupported languages require a verified adapter.'}}
            return {}
        data['baseline']=json.loads(baselinefile.read_text())
        current=run_scan(root,data['latest'],registered_roots(prefix))
        errors=failures(current,data['baseline'])
        data['latest']=current
        statefile.write_text(json.dumps(data)); os.chmod(statefile,0o600)
        if errors:
            reason='Local code guard FAILED. Fix these errors; do not raise limits, add suppressions or reset the baseline.\n'+'\n'.join(errors[:25])
            return {'decision':'block','reason':reason}
        baselinefile.write_text(json.dumps(current)); os.chmod(baselinefile,0o600)
        data['baseline']=current
        statefile.write_text(json.dumps(data)); os.chmod(statefile,0o600)
        return {}
if __name__=='__main__':
    try:
        event=json.load(sys.stdin)
        verify_integrity()
        print(json.dumps(main(event)))
    except Exception as e:
        # An unavailable checker must not be reported as a successful check.
        print(json.dumps({'decision':'block','reason':'Local code guard unavailable: '+str(e)}))
