"""Local review receipts bind the exact candidate and prior document versions."""
import json,os,tempfile
from pathlib import Path
from md_rules import digest,added_units
BASE=Path(__file__).resolve().parent
STATE=BASE/'state'
def read_json(path,default):
    return json.loads(path.read_text()) if path.exists() else default

def atomic_text(path,text):
    path=Path(path); path.parent.mkdir(parents=True,exist_ok=True)
    mode=path.stat().st_mode & 0o777 if path.exists() else 0o600
    fd,name=tempfile.mkstemp(prefix='.md-candidate-',dir=str(path.parent))
    try:
        with os.fdopen(fd,'w') as f: f.write(text); f.flush(); os.fsync(f.fileno())
        os.chmod(name,mode); os.replace(name,path)
    finally:
        if Path(name).exists(): Path(name).unlink()
def receipt_path(target,content):
    key=digest(str(Path(target).resolve()))+'-'+digest(content)
    return STATE/'receipts'/(key+'.json')
def verify_review(review,target,old,new):
    if review.get('target')!=str(Path(target).resolve()): raise ValueError('Review target mismatch.')
    if review.get('base_sha256')!=digest(old): raise ValueError('Stale review: original document changed.')
    if review.get('candidate_sha256')!=digest(new): raise ValueError('Stale review: candidate changed.')
    for field in ['basis','ownership','overlap','conflicts','preservation']:
        if len(str(review.get(field,'')).strip())<12: raise ValueError('Specific semantic review required: '+field)
    approved={r.get('id'):r for r in review.get('clauses',[])}
    for row in added_units(old,new):
        item=approved.get(row['id'],{})
        if len(item.get('reason','').strip())<8: raise ValueError('Unreviewed new/reworded clause: '+row['id'])
        if not item.get('source'): raise ValueError('Clause source required: '+row['id'])
    return True
def approve(target,old,new,review):
    verify_review(review,target,old,new)
    STATE.mkdir(mode=0o700,exist_ok=True); os.chmod(STATE,0o700)
    record=dict(review,review_type='agent semantic review; not independent human approval')
    atomic_text(receipt_path(target,new),json.dumps(record,ensure_ascii=False,indent=2)+'\n')
    managed=read_json(STATE/'managed.json',{})
    managed[str(Path(target).resolve())]=digest(new)
    atomic_text(STATE/'managed.json',json.dumps(managed,ensure_ascii=False,indent=2)+'\n')
def has_receipt(target,text):
    p=receipt_path(target,text)
    if not p.exists(): return False
    record=read_json(p,{})
    return record.get('candidate_sha256')==digest(text) and record.get('target')==str(Path(target).resolve())
